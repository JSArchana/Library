const express = require('express');
const booksRouter = express.Router();

var books =[
    {
        title:'Diary of a Wimpy Kid: The Last Straw',
        author: 'Jeff Kinney',
        img:"book3.jpg"
    },
    {
        title:"Harry Potter and the Philosopher's Stone",
        author: 'J.K. Rowling',
        img:"harry-potter-and-the-sorcerer-s-stone-3.jpg"
    },
    {
        title:'Happy Birthday World',
        author: 'Ruskin Bond',
        img:"book2.jpg"
    }
]

booksRouter.get('/',function(req,res){
    res.render("books",
    {
        nav:[{link:'/books',name:'Books'},{link:'/authors',name:'Authors'},{link:'/signup',name:'Sign Up'},{link:'/signin',name:'Log In'}],
        title:'Regional Library,TVM',
        books
    });
 });
booksRouter.get('/:i',function(req,res){
    const i = req.params.i 
    res.render('book',{
        nav:[{link:'/books',name:'Books'},{link:'/authors',name:'Authors'}],
        title:'Regional Library,TVM',
        book:books[i]  
    });
});