const express = require('express');
const authorRouter = express.Router();

var authors =[
    {
        title:'Diary of a Wimpy Kid: The Last Straw',
        author: 'Jeff Kinney',
        img:"jeff-kenny.jpg"
    },
    {
        title:"Harry Potter and the Philosopher's Stone",
        author: 'J.K. Rowling',
        img:"Rowling.jpg"
    },
    {
        title:'Happy Birthday World',
        author: 'Ruskin Bond',
        img:"Ruskin-Bond.jpg"
    }
]

authorsRouter.get('/',function(req,res){
    res.render("authors",
    {
        nav:[{link:'/books',name:'Books'},{link:'/authors',name:'Authors'},{link:'/signup',name:'Sign Up'},{link:'/signin',name:'Log In'}],
        title:'Regional Library,TVM',
        books
    });
 });
authorsRouter.get('/:i',function(req,res){
    const i = req.params.i 
    res.render('author',{
        nav:[{link:'/books',name:'Books'},{link:'/authors',name:'Authors'}],
        title:'Regional Library,TVM',
        book:books[i]  
    });
});